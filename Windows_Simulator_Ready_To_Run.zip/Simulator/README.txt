Quick start

- Save your assembly files in the Simulator folder.
- Keep charmap.mif in the same folder as your program.
- Edit files with Sublime Text 3 in the Sublime Text 3 folder.
- With Sublime Text open, press F7 to assemble and run the program.

Troubleshooting

- If F7 does not build the program, open Tools > Build System and select Assembly ICMC.
- For other Sublime Text errors, questions, or suggestions, contact carlosasj@hotmail.com.br.